import logging
import openai
import azure.functions as func
from openai import AzureOpenAI 
import json
import os
from dotenv import load_dotenv


load_dotenv()

# Set up your OpenAI API key
AZURE_OPENAI_SERVICE=os.environ.get("AZURE_OPENAI_SERVICE")
AZURE_OPENAI_MODEL=os.environ.get("AZURE_OPENAI_MODEL")
AZURE_OPENAI_SERVICE_KEY=os.environ.get("AZURE_OPENAI_SERVICE_KEY")
AZURE_OPENAI_API_BASE=os.environ.get("AZURE_OPENAI_API_BASE")
#"https://aoai-dreamdemo-gpt4.openai.azure.com/"
AZURE_OPENAI_VERSION=os.environ.get("AZURE_OPENAI_VERSION")
AZURE_OPENAI_TYPE=os.environ.get("AZURE_OPENAI_TYPE")

deployment_name = AZURE_OPENAI_MODEL
openai.api_type = AZURE_OPENAI_TYPE
openai.api_key = AZURE_OPENAI_SERVICE_KEY
openai.api_base = AZURE_OPENAI_API_BASE
openai.api_version = AZURE_OPENAI_VERSION


openai_client = AzureOpenAI(    
    api_key=AZURE_OPENAI_SERVICE_KEY,    
    api_version=AZURE_OPENAI_VERSION,    
    azure_endpoint=AZURE_OPENAI_API_BASE    
) 
def search_answer(questions,data,temperature,max_tokens):
    messages = [
        {"role": "system", "content": "You are an assistant to answer the question from the given context."},
        {"role": "user", "content":f"You are an assistant to answer the {questions} from the {data}.If answer is not in provided in {data} you can answer empathically."}  ]
    response =openai_client.chat.completions.create(
        model=AZURE_OPENAI_MODEL,
        messages=messages
    )
    

    return response.choices[0].message.content

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="func-healthcare-copilot")
def api(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    question = req.params.get('question')
    if not question:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            question = req_body.get('question')
    prompt=req.params.get('prompt')
    if not prompt:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            prompt = req_body.get('prompt')
    temperature=req.params.get('temperature')
    if not temperature:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            temperature = req_body.get('temperature')
    max_tokens=req.params.get('max_tokens')
    if not max_tokens:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            max_tokens = req_body.get('max_tokens')
    answer = search_answer(question,prompt,temperature,max_tokens)
    result = {
        "answer": answer
    }

    return func.HttpResponse(
        body=json.dumps(result),
        mimetype="application/json",
        status_code=200
    )


