window.config = {
  BlobBaseUrl: 'https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/',
  IconBlobBaseUrl:
    'https://#STORAGE_ACCOUNT#.blob.core.windows.net/webappassets/left-nav-icons/',

  APIUrl: 'https://#SERVER_NAME#.azurewebsites.net',
  incedentChatbotAPI:
    'https://#INCEDENT_CHATBOT_SERVER_NAME#.azurewebsites.net/api/func-healthcare-copilot',
  formRecoChatbotAPIURL:
    'https://#FORM_RECO_CHATBOT_SERVER_NAME#.azurewebsites.net/api/func-healthcare-copilot',
  searchAPIURL:
    'https://#SEARCH_API_SERVER_NAME#.search.windows.net/indexes/hospitalincidentsearch-index/docs/search?api-version=2016-09-01',
  searchAPIKeym: '#SEARCH_API_KEY#',
  // APIUrl: 'https://localhost:5001',

  BingMapKey:
    'AhBNZSn-fKVSNUE5xYFbW_qajVAZwWYc8OoSHlH8nmchGuDI6ykzYjrtbwuNSrR8',

  PDFblobInput:
    'https://#STORAGE_ACCOUNT#.blob.core.windows.net/patientintakeform/',
  PDFblobOutput:
    'https://#STORAGE_ACCOUNT#.blob.core.windows.net/formrecogoutput/',

  fc_reportId: '#Healthcare Miami Hospital Overview#',
  // Used in app/pages/campaignreport
  EmbeddedCampaignDashboard_ID: 'b58e0d14-6031-4fde-9eb6-f16d7603b6dc',
  EmbeddedCampaignDashboard_NAME: 'ReportSection01004f62b9c010350168',
  fc_overview: 'ReportSection5691aa74d544b03cf6ed',
  fc_alert: 'ReportSectiond6c63aee8dbd98c9083f',
  fc_production: 'ReportSectionac4bd6f209518e10476c',
  fc_oee: 'ReportSection',
  fc_downtime: 'ReportSection3c5e87c973012471344a',
  fc_energyMaintenance: 'ReportSectiondeef76048dca20b20db0',

  // Used in app/pages/GlobalBing
  gb_reportId: '#Healthcare Global overview tiles#',
  gb_marginId_Honolulu: 'ReportSection2ab692f593997a54fa33',
  gb_bedOccupancyId_Honolulu: 'ReportSection365a5fc783b3142fa5dd',
  gb_patientExpId_Honolulu: 'ReportSection1348a6087741e32baa20',

  gb_marginId_Miami: 'ReportSectionadbc2377f2c7b3656767',
  gb_bedOccupancyId_Miami: 'ReportSection08315d1f93f102e213b0',
  gb_patientExpId_Miami: 'ReportSection5b59605333194e598a3b',

  gb_marginId_Chicago: 'ReportSection8017c7243b47176352ae',
  gb_bedOccupancyId_Chicago: 'ReportSectioncd40a1a6ddca5c21d659',
  gb_patientExpId_Chicago: 'ReportSection1be018e5d3e8518e00a8',

  gb_marginId_Anchorage: 'ReportSectionba94b291ede4db000f97',
  gb_bedOccupancyId_Anchorage: 'ReportSectionddb095ed184c1139b35c',
  gb_patientExpId_Anchorage: 'ReportSectionbc399dbd86c00588e223',

  gb_marginId_LosAngeles: 'ReportSection7dfc3d09b1e1b35991c3',
  gb_bedOccupancyId_LosAngeles: 'ReportSectionf53b9ba997d6ed1498fa',
  gb_patientExpId_LosAngeles: 'ReportSectionf770091f8866c737d416',

  WorldMapReportID: '#Healthcare - US Map#',
  WorldMapReportSectionName: 'ReportSection',

  Dynamic365VideoLink:
    'https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/b922cfb0-c9a5-4f3f-bf90-164ba7fb7558/Demo Clip for d365.ism/manifest',

  HospitalInsightsReportID: '#Healthcare Global Occupational Safety Report#',
  HospitalInsightsReportSectionName: 'ReportSectionff14e21bdad140901345',

  WithoutAzureSynapseLinkReportId: '#Healthcare - HTAP-Lab-Data#',
  WithoutAzureSynapseLinkReportSection_Name:
    'ReportSection7cb15bccee28f85ee6c5',

  WithAzureSynapseLinkReportId: '#Healthcare - HTAP-Lab-Data#',
  WithAzureSynapseLinkReportSection_Name: 'ReportSection0f90f2085202f027fc13',

  PredictiveAnalyticsReport_ID: 'f0d4892e-675b-4159-b122-3de234419bdb',
  PredictiveAnalyticsReportSection_Name: 'ReportSection01004f62b9c010350168',

  HealthHubReportID: '#Healthcare FHIR#',
  HealthHubReportSectionName: 'ReportSection150361fdd687f60e02fd',

  HealthSearchUrl:
    'https://app-health-search.azurewebsites.net/home/index?q=cough,fever',

  HoloLensVideo:
    'https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/c3df01ba-6b90-423e-a92b-474d163073ac/MICROSOFT HEALTH CARE HOLOLENS D.ism/manifest',

  FinaleVideoUrl:
    'https://mediasvcprodhealthcare-usw22.streaming.media.azure.net/acc875b7-4542-4a58-a0f4-f2940285e486/Healthcare_Finale_V014.ism/manifest',

  // Used in app/pages/campaignreport
  EmbeddedCampaignDashboard_ID: '#Healthcare Consolidated Report#',
  EmbeddedCampaignDashboard_NAME: 'ReportSection01004f62b9c010350168',

  BedOccupancyReportID: '#Healthcare - Bed Occupancy & Availability Report#',
  BedOccupancyReportSectionName: 'ReportSectionae2997831bfa33b8ebcc',

  BeforeCallCenterReportID: '#Healthcare - Call Center Power BI Before#',
  BeforeCallCenterSectionName: 'ReportSectionda209890a7f0f9e42736',

  AfterCallCenterReportID: '#Healthcare - Call Center Power BI-After#',
  AfterCallCenterSectionName: 'ReportSection623b64746831c0065bc0',

  AfterCallCenterSummaryReportID: '#Healthcare - Call Center Power BI-After#',
  AfterCallCenterSummarySectionName: 'ReportSectionda209890a7f0f9e42736',

  ClinicalNotesUrl:
    'https://#APP_CRITICAL_NOTES#.azurewebsites.net/#/fce90956-57be-4ec8-ad68-dccfc5129ad1',

  OpenAIChatBotUrl: 'https://#APP_OPEN_AI#.azurewebsites.net/',

  ChatBotDatabricksLink:
    'https://ml.azure.com/fileexplorerAzNB?wsid=/subscriptions/#SUBSCRIPTION_ID#/resourcegroups/#RESOURCE_GROUP_NAME#/providers/Microsoft.MachineLearningServices/workspaces/#ML_WORKSPACE_NAME#&tid=#TENANT_ID#&activeFilePath=1%20Azure%20OpenAI%20Usecases%20for%20Healthcare.ipynb',

  BreakDownReportID: '#Healthcare - Patients Profile report#',
  BreakDownReportSectionName: 'ReportSection9e01a639d7f27865119c',

  KeyInfluencersReportID: '#Healthcare - Patients Profile report#',
  KeyInfluencersReportSectionName: 'ReportSection174cf9bdb5abf0cbb38b',

  RevenueReportID: '#Healthcare Consolidated Report#',
  RevenueReportSectionName: 'ReportSection8b6d7b1114bebe685058',

  AfterRevenueReportID: '#Healthcare Consolidated Report#',
  AfterRevenueReportSectionName: 'ReportSection4d451771c3d80c0b68d8',

  BedOccupancyExternalLink:
    'https://web.azuresynapse.net/en/home?workspace=%2fsubscriptions%2f#SUBSCRIPTION_ID#%2fresourceGroups%2f#RESOURCE_GROUP_NAME#%2fproviders%2fMicrosoft.Synapse%2fworkspaces%2f#SYNAPSE_NAME#',

  SinglePatientReportID: '#Healthcare Patient Overview#',
  SystolicReportSectionName: 'ReportSection8f0ba99268a46e29e619',
  Spo2ReportSectionName: 'ReportSection',
  HeartrateReportSectionName: 'ReportSection8f0ba99268a46e29e619',
  HeartrateReportId: '4a30214d-534f-40b6-90bf-deccab06bdb7', //'#Heart Rate Report',
  SystolicReportId: 'de2b4deb-651e-4c12-af21-32608a3cb3f3', //'#Systolic Report',
  Spo2ReportId: 'eb1421d3-beda-4260-8c08-8e87d30d6299', //'#Spo2 Report',

  //Dashboards (all dashboards are used as gif for now due to realtime widgets not working issue)
  //Used in executive after dashboard id
  HospitalInsightsDashboardID: '',
  PSAfterDashBoard_ID: '',
  PayorExecutiveDashboardID: '',
  PayorExecutiveDashboardAfterID: '',
};
